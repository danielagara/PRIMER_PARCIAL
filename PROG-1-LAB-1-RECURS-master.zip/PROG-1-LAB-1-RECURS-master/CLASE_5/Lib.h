#ifndef LIB_H_INCLUDED
#define LIB_H_INCLUDED


#endif // LIB_H_INCLUDED
int cargaEstado(int estado[], int qtyMaxima);
int obtenerDatos (int edad[], float salario[], int estado[], int qtyMaxima);
int mostrarDatos(int edad[], float salario[], int estado[], int qtyMaxima);
int calcularMaximo(float salario[], int estado[], int qtyMaxima);
int calcularPromedio(int edad[], int estado[], int qtyMaxima, float* promedio);
