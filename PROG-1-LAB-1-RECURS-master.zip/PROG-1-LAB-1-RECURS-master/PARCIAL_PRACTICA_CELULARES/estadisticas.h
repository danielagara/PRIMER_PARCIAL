#ifndef ESTADISTICAS_H_INCLUDED
#define ESTADISTICAS_H_INCLUDED



#endif // ESTADISTICAS_H_INCLUDED
int est_AbonadoMaxLlamadas(EAbonado* arrayAbonados, int lenAbonados, ELlamada* arrayLlamadas, int lenLlamadas);
