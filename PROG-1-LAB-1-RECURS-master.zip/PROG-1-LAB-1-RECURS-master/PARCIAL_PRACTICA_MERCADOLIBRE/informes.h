#ifndef INFORMES_H_INCLUDED
#define INFORMES_H_INCLUDED



#endif // INFORMES_H_INCLUDED
void info_listaPublicaciones(EPublicacionProducto* arrayPublicacionesProductos, int lenPublicaciones, EUsuario* arrayUsuarios, int lenUsuarios);
void info_listaUsuarios(EPublicacionProducto* arrayPublicacionesProductos, int lenPublicaciones, EUsuario* arrayUsuarios, int lenUsuarios);
