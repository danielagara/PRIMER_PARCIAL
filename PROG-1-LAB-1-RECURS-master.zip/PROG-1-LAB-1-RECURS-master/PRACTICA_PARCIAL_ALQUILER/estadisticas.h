#ifndef ESTADISTICAS_H_INCLUDED
#define ESTADISTICAS_H_INCLUDED



#endif // ESTADISTICAS_H_INCLUDED
int est_AsociadoMaxLlamadas(ECliente* arrayClientes, int lenClientes, EAlquiler* arrayAlquileres, int lenAlquileres);
