#ifndef ESTADISTICAS_H_INCLUDED
#define ESTADISTICAS_H_INCLUDED

int est_AsociadoMaxLlamadas(EAsociado* arrayAsociados, int lenAsociados, ELlamadas* arrayLlamadas, int lenLlamadas);

#endif // ESTADISTICAS_H_INCLUDED

