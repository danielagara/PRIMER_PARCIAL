#ifndef COMPARTIDA_H_INCLUDED
#define COMPARTIDA_H_INCLUDED


int comp_bajaProgramadoresEnProyectos(EProgramador* arrayProgramadores, int lenProgramadores, EProyecto* arrayProyectos, int lenProyectos);
void comp_listadoProgramadoresVersion2(EProgramador* arrayProgramadores, int lenProgramadores,
                               EProyecto* arrayProyectos, int lenProyectos, ECategoria* arrayCategorias, int lenCategorias);
#endif // COMPARTIDA_H_INCLUDED
