#ifndef CONSOLA_H_INCLUDED
#define CONSOLA_H_INCLUDED

int TomaNumero(char mensajeInicial[],char mensajeError[], float* numero, float max, float min);

#endif // CONSOLA_H_INCLUDED
