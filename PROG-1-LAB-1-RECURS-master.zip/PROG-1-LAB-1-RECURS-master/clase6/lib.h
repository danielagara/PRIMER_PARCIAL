#ifndef LIB_H_INCLUDED
#define LIB_H_INCLUDED

int imprimePorCaracter(char cadena[]);


#endif // LIB_H_INCLUDED
