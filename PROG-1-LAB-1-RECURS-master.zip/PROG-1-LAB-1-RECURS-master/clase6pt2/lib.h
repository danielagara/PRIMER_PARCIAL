#ifndef LIB_H_INCLUDED
#define LIB_H_INCLUDED

int ordenaArray (int a[], int qtymaxima);

#endif // LIB_H_INCLUDED
