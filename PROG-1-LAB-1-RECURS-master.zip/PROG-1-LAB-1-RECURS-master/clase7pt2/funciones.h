#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

int pasarStringAEntero(char datoAPasar[]);
int tomarNombre(char nombre[], int cantidadMaxima);
int tomarEdad(char edad[], int cantidadMaxima);
#endif // FUNCIONES_H_INCLUDED
